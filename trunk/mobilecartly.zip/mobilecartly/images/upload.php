<head>
<style>
.css-input {
border:none;
margin-top:4px;
font-size:1em;
font-weight:bold;
background-color:#c9f76f;
color:#000000;
width:425px;
padding:4px;
font-family: Arial, Verdana;
display:inline;
}

.css-submit {
border:none;
margin-left:2px;
font-size:1em;
font-weight:bold;
color:#679b00;
background-color:#c9f76f;
width:100px;
padding:7px;
font-family: Arial, Verdana;
display:inline;
}




label {
display:inline;
font-family:helvetica; 
font-size:1.2em;
font-weight:bold;
color:#679b00;
}
</style>
</head>
<body>
<center>
<form enctype="multipart/form-data" action="uploadprocess.php" method="POST">
<input type="hidden" name="MAX_FILE_SIZE" value="2147483648" />
<label>Upload Product Images: (JPG, PNG, GIF - ZIP accepted) </label>
<br><input name="uploadedfile" type="file" class="css-input"/><input type="submit" value="Upload File" class="css-submit"/>
</form>
</center>
</body>