<?
$target_path = "productimages/";

$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 

if(strstr($_FILES['uploadedfile']['name'],'.zip')){
    
    $zip = new ZipArchive; 
    $zip->open($_FILES['uploadedfile']['tmp_name']); 
    $zip->extractTo('productimages/'); 
    $zip->close(); 
    
    echo "<br><center>Zip extracted successfully.</center>";
    
} elseif(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {

    echo "<div style=\"font-size:23px; font-family:helvetica; color:#1569C7;\">";
    echo "<br><center>The file ".  basename( $_FILES['uploadedfile']['name']). 
    " has been uploaded</center></div>";

    echo "<script>setInterval(function(){ window.history.back() },3000);</script>";

    
} else{

    echo "<br><center>There was an error uploading the file, please try again!</center>";
}


?>