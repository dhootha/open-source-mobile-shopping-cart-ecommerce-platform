<!DOCTYPE html> 
<html> 
	<head> 
	<title>MobileCartly | Mobile Shopping Cart for iOS, iPhone, iPad, Android, Blackberry, and Windows Mobile</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css" />
	<link rel="stylesheet" href="css/style.css" />
	<link rel="stylesheet" href="css/input.css" />

	<script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"></script>
	<script src="jqueryextra.js"></script>
	<script src="alterclass.js"></script>
	<script src="paginate.js"></script>
	<script src="stat/traffic.js"></script>
	<script src="shoppingcart/cart.js"></script>
	<script src="shipping/jquery.js"></script>
	
	<script type="text/javascript" src="includes/ckeditor/ckeditor.js"></script>
	<script type="text/javascript" src="includes/ckeditor/adapters/jquery.js"></script>
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Cabin' rel='stylesheet' type='text/css'>
	
	<link type='text/css' href='includes/modal/css/demo.css' rel='stylesheet' media='screen' />
	<link type='text/css' href='includes/modal/css/basic.css' rel='stylesheet' media='screen' />
	
	<? $settings = simplexml_load_file('settings.xml'); ?>
	<? $pages = simplexml_load_file('pages.xml'); ?>
	<? echo file_get_contents('themeheader.html'); ?>

	


</head> 
<body>

<section id="home" class="mc-page" data-role="page" data-theme="<? echo $settings->design; ?>">
<header id="header-store-name" data-role="header" data-position="fixed"><h1><? echo $settings->storename; ?></h1></header>

<div class="content" data-role="content">


<div id="shoppingcart" class="shoppingcart">
<ul data-role="listview"> 
<li><a href="#cart">Shopping Cart</a></li>  
</ul> 
</div>




<!-- DYNAMIC CATEGORIES -->
<div id="categories">
<h3>Browse our mobile store:</h3>
<?
echo file_get_contents("csv/categories/topcat.php");
?>
</div>


<? if(count($pages)==0){} else {?>
<p id="page-label" style="display:none; padding:4px; height:30px;"><h3>Pages:</h3></p>
<? } ?>

<!-- DYNAMIC STORE PAGE LINKS-->
<div id="store-pages"></div>
<?
foreach( $pages as $page ) {
$pageid = str_replace(" ", "", strtolower($page));
echo "<p><ul data-role=\"listview\"><li><a href=\"#mc".$pageid."\">".$page."</a></li></ul></p>";
}
?>




</div> <!-- end main content--->
<footer id="footer-name" data-role="footer"> <h1><? echo $settings->footer; ?></h1></footer>
</section>








//Shopping Cart==========================================
<section id="cart" class="mc-page" data-theme="<? echo $settings->design; ?>" data-role="page">
<header data-role="header" data-position="fixed">
<a href="#home" data-icon="back" data-direction="reverse">back</a>
<h1>Shopping Cart</h1></header>
<div class="content" data-role="content">
<div id="cartdiv"></div>
</div>
</section>
//end shopping cart=====================================





<!-- DYNAMIC STORE PAGE SECTIONS-->
<div id="store-page-sections"></div>
<?
foreach( $pages as $page ) {
$pageid = str_replace(" ", "", strtolower($page));
echo "
<section id=\"mc".$pageid."\" class=\"mc-page\" data-theme=\"". $settings->design ."\" data-role=\"page\">
<header data-role=\"header\" data-position=\"fixed\">
<a href=\"#home\" data-icon=\"back\" data-direction=\"reverse\">back</a>
<h1>" . $page . "</h1></header>
<div class=\"content\" data-role=\"content\">
<br>" . file_get_contents('pages/'.$pageid.'.php') . "</div></section>";
}
?>



<!--  GET DYNAMIC CATEGORIES -->
<?
$dir=dir("csv/categories");

while($getCategories=$dir->read()) {
if($getCategories!='topcat.php'){
echo file_get_contents("csv/categories/".$getCategories);
}
}
$dir->close();
?>


</body>





<?
############################# SECURITY #######################################
$welcomeAdmin = $_REQUEST['security'];
$checkAdmin = file_get_contents("http://mobilecartly.com/security/index.php?apikey=" . $settings->apikey);

if($welcomeAdmin == $checkAdmin || $settings->apikey == '' ){
include("admin/index.php");
} #END SECURITY
?>


</html>