<div id="navigation" style="
left:0px;
right:0px;
margin-left:auto;
margin-right:auto;

bottom:-2px; z-index:1000; color:#1569C7; position:fixed; height:280px; width:1000px; background-color:#efefef; font-family:helvetica;
-webkit-border-radius: 15px 15px 0px 0px;
border-radius: 20px 20px 0px 0px;
border-style:solid;
border-right-width:6px;
border-top-width:5px;
border-left-width:6px;
border-color:lightgrey;
-webkit-box-shadow: 1px 1px 8px .1px #000000;
box-shadow: 1px 1px 8px .1px #000000;
">

<div id="navbtn-container" style="z-index:11;">
<div id="toggle-link" class="navbtn">Hide</div>
<div id="store-link" class="navbtn">Store</div>
<div id="footer-link" class="navbtn">Footer</div>
<div id="design-link" class="navbtn">Design</div>
<div id="import-link" class="navbtn">Import Products</div>
<div id="images-link" class="navbtn">Product Images</div>
<div id="checkout-link" class="navbtn">Shipping</div>
<div id="pages-link" class="navbtn">Pages</div>
</div>
<hr></hr>
<img src="images/icons/topstrip.png" border="0" width="100%" height="30px" style="position:relative; top:-8px;"/>
<img id="menu-arrow" src="images/icons/arrow.png" border="0" width="45" height="23px" style="z-index:10; position:relative; top:-52px; left:102px;"/>
<br>

<div id="newcategory"></div>
<script>
    $("#newcategory").click(function () { 
    	var newcat = "<h3>First list</h3><ul data-role=\"listview\"> <li><a href=\"#\">Item</a></li> <li>Item</li> <li>Item</li> </ul> </div>";
      $("#categories").append(newcat).trigger('create'); 

});
</script>


<!-- ######API KEY####### -->
<?
if(strlen($settings->apikey)< 1){
?>
<div id="enterapikey" class="form-container">
<center>
<form id="apikey">
<input type="text" name="apikey" value="" id="apikey-input" class="css-input" placeholder="Enter your API KEY"/>
<div id="apikeysubmit" class="css-submit">SUBMIT</div><br><br>
<div><a href="http://www.mobilecartly.com"><b>Don't have an API KEY? Get one here</b> (free)</a></div>
</form>
</center>
</div>
<?
}
?>

<script>
$("#apikeysubmit").click(function () { 
var apikey = $("#apikey-input").val();
$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'apikey': apikey, 
    }
});
$('#enterapikey').fadeOut();
});
</script>


<!-- ############   STORE/HEADER   ############# -->
<div id="store-page" style="display:none;" class="form-container">

<center>
<form id="store-form">
<input type="text" name="store-name-input" value="" id="store-name-input" class="css-input" placeholder="Enter your Store Name"/>
<div id="store-submit-btn" class="css-submit">SUBMIT</div>
</form>
</center>
</div>


<script>
$("#store-submit-btn").click(function () { 
var storename = $("#store-name-input").val();
$("#header-store-name").empty().html("<h1 class=\"ui-title\" tabindex=\"0\" role=\"heading\" aria-level=\"1\">" + storename + " - MobileCartly</h1>").trigger('create');
<!-- over here..  write this data to php page, which create storename/header include page -->

$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'storename': storename, 
    }
});

});
</script>





<!-- ############   FOOTER   ############# -->
<div id="footer-page" style="display:none;" class="form-container">

<center>
<form id="footer-form">
<input type="text" name="footer-input" value="" id="footer-input" class="css-input" placeholder="Enter Footer Text"/>
<div id="footer-submit-btn" class="css-submit">SUBMIT</div>
</form>
</center>
</div>


<script>
$("#footer-submit-btn").click(function () { 
var footertext = $("#footer-input").val();
$("#footer-name").empty().html("<h1 class=\"ui-title\" tabindex=\"0\" role=\"heading\" aria-level=\"1\">" + footertext + "</h1>").trigger('create');

$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'footer': footertext, 
    }
});
jq.mobile.changePage("#home");
});
</script>






<!-- ############   DESIGN   ############# -->
<div id="design-page" style="display:none;" class="form-container">

<center>

<div id="design-themes">
<div id="designa" class="design-buttons">A</div>
<div id="designb" class="design-buttons">B</div>
<div id="designc" class="design-buttons">C</div>
<div id="designd" class="design-buttons">D</div>
<div id="designe" class="design-buttons">E</div>
</div>

</center>
</div>

<script>
$("#designa").click(function () {
$( 'section' ).alterClass( 'ui-body-*', 'ui-body-a' ); 
$( 'header' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'footer' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'li' ).alterClass( 'ui-btn-up-*', 'ui-btn-up-a' );

$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'design': 'a', 
    }
});
});




$("#designb").click(function () { 

$( 'section' ).alterClass( 'ui-body-*', 'ui-body-b' );
$( 'header' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'footer' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'li' ).alterClass( 'ui-btn-up-*', 'ui-btn-up-b' );
$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'design': 'b', 
    }
});
});

$("#designc").click(function () { 
$( 'section' ).alterClass( 'ui-body-*', 'ui-body-c' );
$( 'header' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'footer' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'li' ).alterClass( 'ui-btn-up-*', 'ui-btn-up-c' );

$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'design': 'c', 
    }
});
});

$("#designd").click(function () { 
$( 'section' ).alterClass( 'ui-body-*', 'ui-body-d' );
$( 'header' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'footer' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'li' ).alterClass( 'ui-btn-up-*', 'ui-btn-up-d' );

$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'design': 'd', 
    }
}); 
});

$("#designe").click(function () { 
$( 'section' ).alterClass( 'ui-body-*', 'ui-body-e' );
$( 'header' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'footer' ).alterClass( 'ui-bar-*', 'ui-bar-a' );
$( 'li' ).alterClass( 'ui-btn-up-*', 'ui-btn-up-e' );

$.ajax({
    type: 'POST',
    url: 'updatesettings.php',
    data: { 
        'design': 'e', 
    }
});
});
</script>




<!-- ############   IMPORT   ############# -->
<div id="import-page" style="display:none;" class="form-container">

<center>
<iframe src="csv/submit_csv.php" style="border:0px  none;" name="logo-upload" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height="70px" width="630px"></iframe>
</center>
</div>





<!-- ############   IMAGES   ############# -->
<div id="images-page" style="display:none;" class="form-container">

<center>
<iframe src="images/upload.php" style="border:0px  none;" name="images-upload" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height="70px" width="630px"></iframe>
</center>
</div>




<!-- ############   CHECKOUT   ############# -->
<div id="checkout-page" style="display:none;" class="form-container">

<center>
<form id="checkout-form">
<a href="#checkoutdialog" style="color:#679b00; font-size:1.4em; font-weight:bold;">Edit your Shipping Settings</a>
<br><br>
<input type="text" name="checkout-input" id="checkout-input" class="css-input" placeholder="API KEY of another store to use its shipping" style="font-size:1.1em; width:400px;"/>
<input type="submit" name="checkout-id" value="Submit" id="checkout-id" class="css-submit" style="font-size:1.1em;"/>
</form>
</center>
</div>






<!-- ############   PAGES   ############# -->
<div id="pages-page" style="display:none;" class="form-container">

<center>
<a href="#editpagedialog" id="getexistingpages" data-rel="dialog" data-rel="back" style="color:#679b00; font-size:1.4em; font-weight:bold;">Edit an existing page</a>
<br><br>
<input type="text" name="pages-input" id="pages-input"class="css-input" placeholder="Enter New Page Name" style="font-size:1.1em;"/>
<!-- <div id="add-new-page">Add new page</div><br> -->
<input type="submit" value="Add New Page" id="add-new-page" class="css-submit" style="font-size:1.1em; width:140px;"/>


</center>


<script>  
//pages
$('#editpagedialog').live('pageshow',function(event) {
     $("#bottomstrip-img").hide();
     $("#navigation").animate({marginBottom: "-600px"}, 500 ); 
        
      });

$('#editpagedialog').live('pagehide',function(event) {
     $("#navigation").animate({marginBottom: "0px"}, 500 );
     $("#bottomstrip-img").fadeIn(2100);
        
      });
      
      
$('#mcdialog').live('pageshow',function(event) {
     $("#bottomstrip-img").hide();
     $("#navigation").animate({marginBottom: "-600px"}, 500 ); 
        
      });

$('#mcdialog').live('pagehide',function(event) {
     $("#navigation").animate({marginBottom: "0px"}, 500 );
     $("#bottomstrip-img").fadeIn(2100);
        
      });      
      
      
       
//shipping
$('#checkoutdialog').live('pageshow',function(event) {
     $("#bottomstrip-img").hide();
     $("#navigation").animate({marginBottom: "-600px"}, 500 ); 
        
      });

$('#checkoutdialog').live('pagehide',function(event) {
     $("#navigation").animate({marginBottom: "0px"}, 500 );
     $("#bottomstrip-img").fadeIn(2100);
        
      });
</script>



</div> <!-- END ENTIRE MENU / NAVIGATION -->

<!-- JQUERY ADD PAGE -->
<script>
    $("#add-new-page").click(function () {
    	var pagename = $("#pages-input").val();
    	var pageid = pagename.replace(" ", "");
    	
      	$("#page-label").show(); 
	var newpage = "<ul data-role=\"listview\" style=\"margin-top:15px;\"> <li><a href=\"#" + pageid + "\">" + pagename + "</a></li> </ul>";
        $("#store-pages").append(newpage).trigger('create');
        
//ajax php addpage request
$.ajax({
    type: 'POST',
    url: 'includes/addpage.php',
    data: { 
        'pagename': pagename, 
    },
    success: function(msg){
        alert('successfully added page: ' + pagename );
location.reload();

    }
    
});
//add pageid to xml file
$.ajax({
    type: "POST",
    url: "includes/addpagexml.php",
    data: {'addpagexml': pageid, 'addpagenamexml': pagename},
    success: function(msg){
        //alert("Successfully deleted!");

     }
});

});  //end click function
</script>







<!-- NAVIGATION------------------------------------------------------ -->
<img id="bottomstrip-img" src="images/icons/bottomstrip.png" border="0" width="1000px" height="30px" style="position:fixed; bottom:40px;"/>
<div id="navigation-bottom" style="position:fixed; bottom:0px; height:40px; width:100%; color:WHITE; font-family:helvetica;
left:0px;
background: rgb(206, 0, 113) transparent;
background: rgba(206, 0, 113, 0.4);
filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#ce0071, endColorstr=#ce0071);
-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#ce0071, endColorstr=#ce0071)";
">
<div style="padding-left:5px; padding-right:25px; float:right;
color:#ce0071;
margin-top:-17px;
font-family: 'Lobster', Georgia, Times, serif;
font-size: 40px;
">MobileCartly</div>


</div>
</div> <!-- end navigation -->







<!-- Edit PAge DIALOG -->
<div data-role="page" id="mcdialog">
    <div data-role="header">
        <h1>Editing page: <div id="currentpage" style="display:inline;"></div></h1>
    </div>
    <div data-role="content">
	
	
	<div data-role="none">
	<textarea class="editor" name="editor"></textarea>
	</div>
	
	
	<center>
	<div data-role="controlgroup" data-type="horizontal">
	<button id="save-editor" data-inline="true"> SAVE PAGE </button> <button id="delete-page" data-inline="true">DELETE PAGE</button>
	</div>
	</center><br>
    </div>
</div>



<script>
//SAVE PAGE BUTTON
$(document).ready(function() {

$("#save-editor").click(function () { 
var pageContent = $( '.editor' ).val();
var pageBeingSaved = $("#currentpage").text();



$.ajax({
    type: "POST",
    url: "includes/savepage.php",
    data: {'savepage': pageBeingSaved, 'pagecontent': pageContent},
    success: function(msg){
        alert("Successfully saved page: " + pagename );
    }
});
alert("Saved Successfully.");

});
});

</script>

<script>
//DELETE PAGE BUTTON
$(document).ready(function() {

$("#delete-page").click(function () { 
var pageBeingDeleted = $("#currentpage").text();

$.ajax({
    type: "POST",
    url: "includes/deletepage.php",
    data: {'deletepage': pageBeingDeleted},
    success: function(msg){
        //alert("Successfully deleted!");

     }
});
//delete pageid from xml file
var pageid = "mc-" + pageBeingDeleted.replace(".php","");
var pageid = pageid.toLowerCase();
alert(pageid);
$.ajax({
    type: "POST",
    url: "includes/deletepagexml.php",
    data: {'deletepagexml': pageid},
    success: function(msg){
        alert("Successfully deleted!");

     }
});
function goBack() {
	history.back();
	return false;
}
goBack();
location.reload();
});
});

</script>






<!-- EDIT PAGE DIALOG -->
<div data-role="page" id="editpagedialog">

    <div data-role="header"><h1>Edit or Delete a page</h1></div>
    	
    	<div data-role="content">
    
<ul data-role="listview" id="existingpages">

<!-- PHP GET PAGES WAS HERE..  MOVED TO getpages.php -->
<?
#get pages dynamically
$dir=dir("pages/");

while($pagenameorig = $dir->read()) {

$pagename = str_replace('-', ' ',  $pagenameorig);
$pagename = str_replace('.php', '',  $pagename);
$pagename = ucfirst($pagename);

if(  strlen($pagename) > 2  ){
echo "<li><a href=\"#mcdialog\" data-rel=\"dialog\" data-rel=\"back\" class=\"pagelink\" id=\"" . strtolower($pagenameorig) . "\">" . $pagename . "</a></li>";
}
}
?>
</ul>

	</div> <!--end content-->
    
</div>  <!-- end PAGE DIALOG -->


<script>
//Get page content dynamically.
$(document).ready(function() {

    $(".pagelink").click(function () {
    
    	var currentpage = $(this).attr('id');
    	$("#currentpage").html(currentpage);
    	$( '.editor' ).ckeditor();
    	
    	var content = $.ajax({
                url: "pages/" + currentpage,
                async: false
            }).responseText;
	$( '.editor' ).val(content);
    });
    });
</script>  	




<div data-role="page" id="checkoutdialog">
<div data-role="header"><h1>Shipping Settings</h1></div>
<div data-role="content">
<? 
echo file_get_contents('http://'.$_SERVER['SERVER_NAME'].'/mobilecartly/shipping/index.php'); 
?>
</div>
</div>