<?php



############################################################################
#
#                                  THEME
#
############################################################################

$settings = simplexml_load_file('../settings.xml');
$apikey = $settings->apikey;
$thissite = $_SERVER['SERVER_NAME'];

#themeid
$themeid=$_REQUEST['themeid'];

##GET THEME
if($themeid=='default'){

#$header = file_get_contents('http://mobilecartly.com/developers/themes/header/' . $themeid . '.php');
#$topcode = file_get_contents('http://mobilecartly.com/developers/themes/topcode/' . $themeid . '.php');
$midcode = file_get_contents('http://mobilecartly.com/developers/themes/midcode/' . $themeid . '.php');
#$bottomcode = file_get_contents('http://mobilecartly.com/developers/themes/bottomcode/' . $themeid . '.php');

} else {

#CURL VERIFY API AND PERMISSION + GET THEME CODE
$postfields = array('apikey' => urldecode($apikey), 'storeurl' => $thissite, 'themeid' => $themeid);
$params = http_build_query($postfields);


$ch = curl_init("http://mobilecartly.com/theme-permission-ok.php");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$themeok = curl_exec($ch);
curl_close($ch);

$themecode = explode('[MC]', $themeok);

$header = $themecode[0];
$topcode = $themecode[1];
$midcode = $themecode[2];
$bottomcode = $themecode[3];
} 





#write dynamic header to themeheader.html
file_put_contents('../themeheader.html', $header, FILE_APPEND);






############################################################################
#
#                                  UPLOAD/GET CSV FILE
#
############################################################################

#if file is CSV
if (strstr($_FILES["process_csv"]["name"], ".csv"))

    {






#if the file exists...  delete file, then upload new file....
if (file_exists("upload/" . $_FILES["process_csv"]["name"]))
      {
      unlink("upload/"  . $_FILES["process_csv"]["name"]);
      
      move_uploaded_file($_FILES["process_csv"]["tmp_name"],
      "upload/" . $_FILES["process_csv"]["name"]);
      }
    else
      {
      #else if file does not exist in folder..  upload.
      move_uploaded_file($_FILES["process_csv"]["tmp_name"],
      "upload/" . $_FILES["process_csv"]["name"]);
      }
      
  
   
   
   
   
   
   





############################################################################
#
#                             PRODUCTS/CATEGORIES
#
############################################################################






#    DELETE PRODUCT AND CAT FILES (start fresh)
$dir=dir("categories/");

while($filedelete=$dir->read()) {

if($filedelete!="topcat.php" && strstr($filedelete, ".php" )){
unlink("categories/".$filedelete);
}
file_put_contents("categories/topcat.php","");
}
$dir->close();









#	GET CSV FILE FROM UPLOAD DIR - production
$dir=dir("upload/");

while($filename=$dir->read()) {

if(strstr($filename, '.csv')){
$file="upload/".$filename;
break;
}
}
$dir->close();
  

#	Read product data from CSV file.
$delimiter = ',';



# Open the File.
    if (($handle = fopen($file, "r")) !== FALSE) {
        # Set the parent multidimensional array key to 0.
        $nn = 0;
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            # Count the total keys in the row.
            $c = count($data);
            # Populate the multidimensional array.
            for ($x=0;$x<$c;$x++)
            {
                $csvarray[$nn][$x] = $data[$x];
            }
            $nn++;
        }
        # Close the File.
        fclose($handle);
    }

    
    
    #loop thru all entire array
    for ($i=1; $i<=count($csvarray); $i++){
    
    #get first column of array (category)
    $cats[] = $csvarray[$i][0];
    }
    
    #get unique categories
    foreach(array_unique($cats) as $val){
    
    ################################################## (1) TOPCAT - NO SUB CATS - GET PRODUCTS
    if(!strstr($val, '>') && strlen($val) > 1){
    #echo $val . "<br>";

    #add top cat
    addTopCategory($val);

    #add products to topcat
    getProductsFromCat(1, $val, '', '');
    
    ################################################## (1) TOPCAT - YES SUB CATS - NO PRODUCTS
    } elseif( strstr($val, '>') && strlen($val) > 1 ){
    
    $counter++;
    
    #split the sub categories
    $subcats = explode('>', $val, 2);
 
    if ($counter == 1) {
    #--------main category in subcategory
    #echo "<h1>".$subcats[0]."</h1><br>";
    
    #write to topcat.php
    addTopCategory($subcats[0]);
    
    
    
    #set top category name
    $finalTopCatName = $subcats[0];
    }
    
    
    ################################################## (2) SECOND - NO SUB CAT - YES PRODUCTS
    if(!strstr($subcats[1], '>') && strlen($subcats[1]) > 1){
    #echo "<h2>|__".$subcats[1] . "</h2><br>";
    
    
    
    #add subcategory to page
    addSubCategory($subcats[1], $finalTopCatName);
    addSecondSubCatPage($subcats[1]);

    
    #add products to subcat
    getProductsFromCat(2, $subcats[0], $subcats[1], '');
    
    #set second top category name
    $finalSecondTopCatName = $subcats[1];
    
    

    
    
    
    ################################################## (2) SECOND - YES SUB CATS - NO PRODCUTS
    } elseif(strstr($subcats[1], '>') && strlen($subcats[1]) > 1){    
    
    #### get THRID sub category
    $subcats2 = explode('>', $subcats[1], 2);
    #echo "<h3>|__|__".$subcats2[1]."</h3><br>";
    
   #MENS $subcats2[0]
   #BOYS $subcats2[1]
   
    
    addSubCategory($subcats2[0], $finalTopCatName);
    addSecondSubCatPage($subcats2[0]);
    

    
    ################################################## (3) THIRD - NO SUBCATS - YES PRODCUTS
    addSubCategory($subcats2[1], $subcats2[0]);
    addSecondSubCatPage($subcats2[1]);
    
    #add products to THIRD subcat
    getProductsFromCat(3, $finalTopCatName, $subcats2[0], $subcats2[1]);
    
    


    } #end get second subcat    
    } #end get subcats
    } #end main loop












   
   
   
   
   
   
      
      
      
############################################################################
#
#                                  END
#
############################################################################
    
  echo "<div style=\"font-size:23px; font-family:helvetica; color:#1569C7;\">";
  echo "<center>Successfully uploaded products!</center>";
  echo "</div>";
  echo "<script>setInterval(function(){ window.history.back() },3000);</script>";

  }
else
  {
  echo "<div style=\"font-size:23px; font-family:helvetica; color:#1569C7;\">";
  echo "<center>Sorry, Invalid file.<br>File must be a CSV file.</center>";
  echo "</div>";
  }
  
 

  
  #update PRODUCTS in MobileCartly  (trigger create)
  ## http://stackoverflow.com/questions/4689145/pass-jquery-variables-between-iframe-and-parent
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 
  
  
  
############################################################################
#
#                                  FUNCTIONS
#
############################################################################

  
    
    #function to get products..
    function getProductsFromCat($thiscat, $firstCat, $secondCat, $thirdCat){
    #get full cat name
    $catName = $firstCat.$secondCat.$thirdCat;
    #remove whitespace and lowercase.
    $catName = strtolower(str_replace(' ', '', $catName));
    
    
    ###########LAST WORK HERE:  need to make product pages with last category.. then get template and write to products page
    #get current loop category name
    if($thiscat == '1'){
    $thiscat = strtolower(str_replace(' ', '', $firstCat));
    } elseif ($thiscat == '2'){
    $thiscat = strtolower(str_replace(' ', '', $secondCat));
    } else {
    $thiscat = strtolower(str_replace(' ', '', $thirdCat));
    }
   
    
    
    #new csvarray
    $cats = getData();
    
    
    #loop thru categories... and match.... then get products.
    for ($z=1; $z<=count($cats); $z++){
    
    #if cats name matches.. get products, get template, write to file.
    if(  (strtolower(str_replace('>', '', str_replace(' ', '', $cats[$z][0]))) == $catName )  ){
    
    #WRITE PRODUCT TO FILE FUNCTION
    writeThemeProducts($thiscat, $z, $cats[$z][1], $cats[$z][2], $cats[$z][3], $cats[$z][4]);
    
    #echo $cats[$z][1] . "<br>";
    
    } #end if loop
    } #end foreach loop 
    } #end get products function
    



function writeThemeProducts($thiscat, $mcid, $mctitle, $mcprice, $mcimg, $mcdesc){
$mcid = "productid-".$mcid;
$mcimg = "../../images/".$mcimg;

if(file_exists($mcimg)){
$mcimg = "../../images/".$mcimg;
}else{
$mcimg = "../../images/default.png";
}

#replace THEME
$productwithTheme = str_replace('[MC=id]', $mcid, $GLOBALS['midcode']);
$productwithTheme = str_replace('[MC=title]', $mctitle, $productwithTheme);
$productwithTheme = str_replace('[MC=description]', $mcdesc, $productwithTheme);
$productwithTheme = str_replace('[MC=img]', $mcimg, $productwithTheme);
$productwithTheme = str_replace('[MC=price]', $mcprice, $productwithTheme);


$shoppingcartcode = "
<center><div id=\"" . $mcid . "\" class=\"addtocart\" style=\"width:200px;\">
<select name=\"slider\" data-role=\"slider\">
	<option value=\"off\">Add to cart</option>
	<option value=\"on\">Added</option>
</select>
</div></center><hr><br>";
$finalProduct = "<div class=\"paginate\">" . $productwithTheme.$shoppingcartcode . "</div>";



if(file_exists("categories/mcsub-" . strtolower($thiscat) . ".php"  )){
$productFilePath = "categories/mcsub-" . strtolower($thiscat) . ".php";
} elseif(file_exists("categories/mcsec-" . strtolower($thiscat) . ".php"  )){ 
$productFilePath = "categories/mcsec-" . strtolower($thiscat) . ".php";
}

## APPEND / WRITE CODE TO FILE
$productFileAppend = file_get_contents($productFilePath);
$productFileAppend = str_replace('</div></section>', '', $productFileAppend);
$productFileAppend = $productFileAppend.$finalProduct."</div></section>";

file_put_contents($productFilePath, $productFileAppend);
## END APPEND / WRITE



}  #end of writeThemeProducts Function





    
    
function getData(){
$dir=dir("upload/");

while($filename=$dir->read()) {

if(strstr($filename, '.csv')){
$file="upload/".$filename;
break;
}
}
$dir->close();

$delimiter = ',';
    
    if (($handle = fopen($file, "r")) !== FALSE) {
        # Set the parent multidimensional array key to 0.
        $nn = 0;
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            # Count the total keys in the row.
            $c = count($data);
            # Populate the multidimensional array.
            for ($x=0;$x<$c;$x++)
            {
                $csvarray[$nn][$x] = $data[$x];
            }
            $nn++;
        }
        # Close the File.
        fclose($handle);
    }
    return $csvarray;
}   
    
    
    
function addTopCategory($topCatName){

if (strlen($topCatName) > 0){
$topCatId = strtolower(str_replace('>', '', str_replace(' ', '', $topCatName)));
$topCatTemplate = "<p id=\"" . $topCatId . "\"><ul data-role=\"listview\"><li><a href=\"#" . $topCatId . "\">" . $topCatName . "</a></li></ul></p>";

#append to topcat.php
$topCatFile = 'categories/topcat.php';
file_put_contents($topCatFile, $topCatTemplate, FILE_APPEND);

#create subcatpage
$topSubTemplate = "<section id=\"" . $topCatId . "\" class=\"mc-page\" data-theme=\"c\" data-role=\"page\">
<header data-role=\"header\" data-position=\"fixed\">
<a href=\"#home\" data-icon=\"back\" data-direction=\"reverse\">home</a>
<h1>" . $topCatName . "</h1>
<a href=\"#cart\" class=\"shoppingcart\" data-icon=\"check\">Checkout</a>
</header>
<div class=\"content\" data-role=\"content\"></div></section>";

$topSubFile = 'categories/mcsub-' . $topCatId . '.php';
file_put_contents($topSubFile, $topSubTemplate);
}

}
    


function addSubCategory($subCatName, $finalTopCatName){
$topCatId = strtolower(str_replace('>', '', str_replace(' ', '', $finalTopCatName)));
$subCatId = strtolower(str_replace('>', '', str_replace(' ', '', $subCatName)));

$subCatTemplate = "<p id=\"" . $subCatId . "\"><ul data-role=\"listview\"><li><a href=\"#" . $subCatId . "\">" . $subCatName . "</a></li></ul></p></div></section>";

#remove </div></section> then append
$subCatAppend = file_get_contents('categories/mcsub-' . $topCatId . '.php');
$subCatAppend = str_replace('</div></section>', '', $subCatAppend);
$subCatAppend = $subCatAppend.$subCatTemplate;

$subCatFile = 'categories/mcsub-' . $topCatId . '.php';
file_put_contents($subCatFile, $subCatAppend);

}



function addSecondSubCat($secondSubCatName, $secondTopCatName){
$secondTopCatId = strtolower(str_replace('>', '', str_replace(' ', '', $secondTopCatName)));
$secondSubCatId = strtolower(str_replace('>', '', str_replace(' ', '', $secondSubCatName)));

$secondTopCatTemplate = "<p id=\"" . $secondSubCatId . "\"><ul data-role=\"listview\"><li><a href=\"#" . $secondSubCatId . "\">" . $secondSubCatName . "</a></li></ul></p></div></section>";

#remove </div></section> then append
$secSubCatAppend = file_get_contents('categories/mcsub-' . $secondTopCatId . '.php');
$secSubCatAppend = str_replace('</div></section>', '', $secSubCatAppend);
$secSubCatAppend = $secSubCatAppend.$secondTopCatTemplate;

$secSubCatFile = 'categories/mcsub-' . $secondTopCatId . '.php';
file_put_contents($secSubCatFile, $secSubCatAppend);
}





function addSecondSubCatPage($secondTopCatName){
$topCat2Id = strtolower(str_replace('>', '', str_replace(' ', '', $secondTopCatName)));

$secondTopSubHeader = "<section id=\"" . $topCat2Id . "\" class=\"mc-page\" data-theme=\"c\" data-role=\"page\">
<header data-role=\"header\" data-position=\"fixed\">
<a href=\"#home\" data-icon=\"back\" data-direction=\"reverse\">home</a>
<h1>" . $secondTopCatName . "</h1>
<a href=\"#cart\" class=\"shoppingcart\" data-icon=\"check\">Checkout</a>
</header>
<div class=\"content\" data-role=\"content\"></div></section>";

$secondTopSubFile = 'categories/mcsub-' . $topCat2Id . '.php';
file_put_contents($secondTopSubFile, $secondTopSubHeader);

}


function addLastProductsPage($thiscat){
$thiscat = strtolower(str_replace('>', '', str_replace(' ', '', $thiscat)));

$thisCatTemplate = "<section id=\"" . $thiscat . "\" class=\"mc-products-" . $thiscat . "\" data-role=\"page\" data-theme=\"e\">
<header id=\"header-store-name\" data-role=\"header\" data-position=\"fixed\">
<a href=\"#home\" data-icon=\"back\" data-direction=\"reverse\">home</a>
<h1>MobileCartly.com</h1>
<a href=\"#cart\" class=\"shoppingcart\" data-icon=\"check\">Checkout</a>
</header>
<div class=\"content\" data-role=\"content\"></div></section>";

$thisCatFilename = 'categories/mcproduct-' . $thiscat . '.php';
file_put_contents($thisCatFilename, $thisCatTemplate);
}  
  
  
  
  

  
  
  
  
  
  
  
  
  
  
  
  
  
?>