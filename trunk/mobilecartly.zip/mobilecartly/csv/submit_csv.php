<?
$settings = simplexml_load_file('../settings.xml');
$apikey = $settings->apikey;
$thissite = $_SERVER['SERVER_NAME'];
?>
<head>
<style>
.css-input {
border:none;
margin-top:-1px;
font-size:1em;
font-weight:bold;
background-color:#c9f76f;
color:#000000;
width:425px;
padding:4px;
font-family: Arial, Verdana;
display:inline;
}

.css-input-drop {
border:none;
margin-top:1px;
font-size:1em;
font-weight:bold;
background-color:#c9f76f;
color:#000000;
width:320px;
padding:4px;
font-family: Arial, Verdana;
display:inline;
}

.css-submit {
border:none;
margin-top:-1px;
font-size:1em;
font-weight:bold;
color:#679b00;
background-color:#c9f76f;
width:100px;
padding:5.5px;
font-family: Arial, Verdana;
display:inline;
}




label {
display:inline;
font-family:helvetica; 
font-size:1.2em;
font-weight:bold;
color:#679b00;
}
</style>
</head>


<body>

<!--<div style="margin-left:50px; font-family:helvetica; color:#679b00; font-size:1.3em; font-weight:bold;">-->

<div class="form-container">
<form action="process_csv.php" method="post" enctype="multipart/form-data" style="margin-left:50px;">
<label for="file" style="display:inline;">CSV File: <a href="sample.csv" target="_blank" style="font-size:14px">Sample</a> </label>
<input type="file" name="process_csv" id="process_csv" class="css-input"/>
<br>

<label for="theme">Theme:&nbsp;&nbsp;&nbsp;</label>
<select name="themeid" class="css-input-drop">
<?
echo file_get_contents("http://mobilecartly.com/theme-permission.php?apikey=" . $apikey . "&storeurl=" . $thissite);
?>
</select>
<input type="submit" name="submit" value="Submit" class="css-submit"/>
</form>
</div>

</div>

</body>