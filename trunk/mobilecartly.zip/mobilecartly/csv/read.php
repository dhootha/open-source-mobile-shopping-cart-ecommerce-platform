<?php

#	GET FILE FROM UPLOAD DIR
$dir=dir("upload/");

while($filename=$dir->read()) {

if(strstr($filename, '.csv')){
echo $filename;
$file=$filename;
}

}
$dir->close();
  

#	Read product data from CSV file.
#$file = 'MASTER_PRODUCT_LIST.csv';
$delimiter = ',';



# Open the File.
    if (($handle = fopen("upload/".$file, "r")) !== FALSE) {
        # Set the parent multidimensional array key to 0.
        $nn = 0;
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            # Count the total keys in the row.
            $c = count($data);
            # Populate the multidimensional array.
            for ($x=0;$x<$c;$x++)
            {
                $csvarray[$nn][$x] = $data[$x];
            }
            $nn++;
        }
        # Close the File.
        fclose($handle);
    }
    # Print the contents of the multidimensional array.
    //print_r($csvarray);
    
    echo $csvarray[1001][0] . "<br>";
    echo $csvarray[1001][1] . "<br>";
    echo $csvarray[1001][2] . "<br>";
    echo $csvarray[1001][3] . "<br>";
    echo $csvarray[1001][4] . "<br>";
    echo "<br><br>";
    
    echo count( $csvarray );
    
?>