$(document).ready(function() {
$( ".addtocart" ).bind( "change", function(event, ui) {
  
 var selectedId = $('option:selected', this).val();
 var productAdded = $(this).attr('id');

  if (selectedId == "off") {
    //alert('REMOVED FROM CART' + productAdded);
    
    $.ajax({
    type: "POST",
    url: "shoppingcart/remove.php",
    data: {'product': productAdded},
    success: function(msg){

$('#cart').page(); // Re-render the page otherwise the dynamic content is not styled.
$('#cart').trigger("create"); // insert data to the jqMobile page (which is a div).

     }
});
    
  }

  if (selectedId == "on") {
    //alert('ADDED TO CART' + productAdded);
    
    $.ajax({
    type: "POST",
    url: "shoppingcart/add.php",
    data: {'product': productAdded},
    success: function(msg){
    
$('#cart').page(); // Re-render the page otherwise the dynamic content is not styled.
$('#cart').trigger("create"); // insert data to the jqMobile page (which is a div).

     }
});
    
  }    
      
});
});



$(document).ready(function() {
$(".shoppingcart").click(function() {

$.post("stat/checkout.php");

$.get("shoppingcart/checkout.php", function(data) { // load content from external file
$('#cartdiv').html(data); // insert data to the jqMobile page (which is a div).
$('#cart').page(); // Re-render the page otherwise the dynamic content is not styled.
$('#cart').trigger("create"); // insert data to the jqMobile page (which is a div).

});

});
});



