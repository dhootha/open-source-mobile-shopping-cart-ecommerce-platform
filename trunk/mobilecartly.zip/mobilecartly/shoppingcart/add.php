<?
$product = $_REQUEST['product'];




#If cookie exists... add product

if( isset( $_COOKIE['MCCHECKOUT'] ) ) {
$checkout = unserialize($_COOKIE['MCCHECKOUT']);
$checkout[] = $product;

setcookie('MCCHECKOUT', serialize($checkout), time()+10800);

#print_r($checkout);

#If cookie does not exist..  create
} elseif (!isset( $_COOKIE['MCCHECKOUT'] )){

$checkout = array(0 => $product);
setcookie('MCCHECKOUT', serialize($checkout), time()+10800);

}









#$a = array(0 => 'one', 1 => 'two', 2 => 'three', );
#array_push($a, "four");

#for ($xx = 0; $xx < count($a); $xx++){
#if ($a[$xx]=='two'){
#unset($a[$xx]);
#}
#$a = array_values($a);
#}

#print_r($a);


#deletes cookie
#setcookie('MCCHECKOUT', null, strtotime('-1 day'));

?>