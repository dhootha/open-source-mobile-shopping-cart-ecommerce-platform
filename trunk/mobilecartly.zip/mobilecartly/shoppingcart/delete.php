<?
#Deletes cookie.. used for testing.
setcookie('MCCHECKOUT', null, strtotime('-1 day'));
?>