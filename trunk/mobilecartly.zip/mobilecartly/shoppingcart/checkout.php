<?
#get seller URL to CSV
require_once('getCurrentCSV.php');
$sellerCSV = $csvFilePath;


$settings = simplexml_load_file('../settings.xml');
$apikey = $settings->apikey;

if( isset( $_COOKIE['MCCHECKOUT'] ) ) {
$checkout = unserialize($_COOKIE['MCCHECKOUT']);


?>
<script>


function subtotal(){
var subtotal = 0;
$('.price').each (function (){
subtotal += ($(this).html() * 1);
});
$('#subtotal').html(subtotal);
$('[name=subtotal]').val(subtotal);

}


$(document).ready(function() {
subtotal();
});



$(document).ready(function() {
$('[name=sellerurl]').val(window.location.href);
});



$(document).ready(function() {
$(".removeproduct").click(function() {
$(this).closest('li').fadeOut().remove();
subtotal();
});
});



$(document).ready(function() {
//$(".qty").mouseup(function() {
$(".qty").change(function() {
var price = $(this).closest('li').val();
var qty = $(this).parent().find(".quantity").val();
var updateprice = price * qty;
$(this).parent().find(".price").html(updateprice);
subtotal();
});
});
</script>
<?

echo "<form name=\"checkout\" action=\"http://www.mobilecartly.com/orders/shipping/index.php\" method=\"post\">";

echo "<ul data-role=\"listview\" data-inset=\"true\"><li style=\"font-size:1.5em;\">";
echo "<center>Subtotal:   $<div id=\"subtotal\" style=\"display: inline;\"></div>";
echo "</center></li></ul>";

echo "<ul data-role=\"listview\" data-inset=\"true\">";

foreach($checkout as $c){
$c = str_replace('productid-', '', $c);

$products = getData($c);
#print_r($products);

$productname = $products[$c][1];
$productprice = $products[$c][2];
$productimg = $products[$c][3];

echo "<li id=\"productid-" . $c . "\"  value=\"" . $productprice . "\">

<div value=\"productid-" . $c . "\" class=\"removeproduct\" style=\"float:left;\" data-role=\"button\" data-icon=\"delete\" >remove</div>

<font size=\"6\">
<div style=\"float:right; display:inline;\">$ <div class=\"price\" style=\"display:inline;\">" . $productprice . "</div></div>
</font>
<br><Br><br>
<div style=\"word-wrap:break-word; padding:5px;\">
<font size=\"3\">" . $products[$c][1] . "</font>
</div>
<br>



<!-- SLIDER / QTY -->
<div class=\"qty\" style=\"width:100%;\">
<label for=\"slider-step\" style=\"padding:5px;\">Quantity:</label>

<input type=\"hidden\" name=\"product[]\" value=\"productid-" . $c . "\" />
<input type=\"range\" name=\"quantity[]\" class=\"quantity\" value=\"1\" min=\"1\" max=\"10\" step=\"1\" style=\"display:inline; float:right;\"/>
<br>
</div>




</li>
";

} #### END FOR EACH LOOP

echo "<input type=\"hidden\" name=\"sellerurl\" value=\"" . $sellerCSV . "\" />";
echo "<input type=\"hidden\" name=\"subtotal\" value=\"\" />";
echo "<input type=\"hidden\" name=\"apikey\" value=\"" . $apikey . "\" />";


##http://stackoverflow.com/questions/3314567/how-to-get-form-input-array-into-php-array
echo "</ul>";


echo "<h1><input type=\"submit\" name=\"submit\" data-role=\"button\" style=\"font-size:1.6em;\" value=\"Checkout\" /></h1>";








###########################################
#nothing in cart
} elseif (!isset( $_COOKIE['MCCHECKOUT'] )){

echo "<center>Your Cart is empty!</center>";

}





function getData($productid){
$dir=dir("../csv/upload/");

while($filename=$dir->read()) {

if(strstr($filename, '.csv')){
$file="../csv/upload/".$filename;
break;
}
}
$dir->close();

$delimiter = ',';
    
    if (($handle = fopen($file, "r")) !== FALSE) {
        # Set the parent multidimensional array key to 0.
        $nn = 0;
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            # Count the total keys in the row.
            $c = count($data);
            # Populate the multidimensional array.
            for ($x=0;$x<$c;$x++)
            {
            	
            	if($nn == $productid){
                $csvarray[$nn][$x] = $data[$x];
                }
                
            }
            $nn++;
        }
        # Close the File.
        fclose($handle);
    }
    return $csvarray;
} 




?>