<?
$product = $_REQUEST['product'];




#If cookie exists... add product

if( isset( $_COOKIE['MCCHECKOUT'] ) ) {

$checkout = unserialize($_COOKIE['MCCHECKOUT']);


for ($xx = 0; $xx < count($checkout); $xx++){
if ($checkout[$xx]==$product){
unset($checkout[$xx]);
}
$checkout = array_values($checkout);
}



setcookie('MCCHECKOUT', serialize($checkout), time()+10800);


}

#print_r($checkout);







#$a = array(0 => 'one', 1 => 'two', 2 => 'three', );
#array_push($a, "four");

#for ($xx = 0; $xx < count($a); $xx++){
#if ($a[$xx]=='two'){
#unset($a[$xx]);
#}
#$a = array_values($a);
#}

#print_r($a);


#deletes cookie
#setcookie('MCCHECKOUT', null, strtotime('-1 day'));

?>