<?

$currentUrl = selfURL();
$csvFileName = "csv/upload/". getCurrentCSV();


$csvFilePath = str_replace('shoppingcart/checkout.php', $csvFileName, $currentUrl);



function selfURL() {
	$s = empty($_SERVER["HTTPS"]) ? ''
		: ($_SERVER["HTTPS"] == "on") ? "s"
		: "";
	$protocol = strleft(strtolower($_SERVER["SERVER_PROTOCOL"]), "/").$s;
	$port = ($_SERVER["SERVER_PORT"] == "80") ? ""
		: (":".$_SERVER["SERVER_PORT"]);
	return $protocol."://".$_SERVER['SERVER_NAME'].$port.$_SERVER['REQUEST_URI'];
}
function strleft($s1, $s2) {
	return substr($s1, 0, strpos($s1, $s2));
}


function getCurrentCSV(){
$dir=dir("../csv/upload");

while($filename=$dir->read()) {

if(strstr($filename, '.csv')){
return $filename;
break;
}
}
$dir->close();
}

?>