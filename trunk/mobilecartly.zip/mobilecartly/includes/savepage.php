<?

$page = "../pages/" . $_REQUEST['savepage'];
$content = $_REQUEST['pagecontent'];


file_put_contents($page, $content);

?>