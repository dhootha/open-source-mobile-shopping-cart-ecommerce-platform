<?
$mcpost = str_replace(' ', '-', $_REQUEST['pagename']); 
$pagename = "../pages/" . $mcpost . ".php";
$pagename = strtolower($pagename);

$mc = fopen($pagename, 'w') or die("can't open file");
fclose($mc);
?>