<form name="input" action="addpage.php" method="post">
Username: <input type="text" name="pagename" />
<input type="submit" value="Submit" />
</form>