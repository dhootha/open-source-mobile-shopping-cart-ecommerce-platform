<?

$page = "../pages/" . $_REQUEST['deletepage'];

unlink($page);


?>