<?
$addpagexml = $_POST['addpagexml'];
$addpagexml = strtolower($addpagexml);

$addpagenamexml = $_POST['addpagenamexml'];

$pages = simplexml_load_file('../pages.xml');


if(isset($addpagexml)){
$tag = 'mc-'.$addpagexml;
$pages->$tag = $addpagenamexml;
}



#save data
$pages->asXML('../pages.xml');

?>