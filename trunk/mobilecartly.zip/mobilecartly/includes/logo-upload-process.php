<?php
if (($_FILES["logo-upload"]["type"] == "image/gif") 
|| ($_FILES["logo-upload"]["type"] == "image/jpeg") 
|| ($_FILES["logo-upload"]["type"] == "image/pjpeg")
&& ($_FILES["logo-upload"]["size"] < 20000))
  {
  
  if ($_FILES["logo-upload"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["logo-upload"]["error"] . "<br />";
    }
  else
    {

    if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/appcode/images/logo/" . $_FILES["logo-upload"]["name"]))
      {
      unlink($_SERVER['DOCUMENT_ROOT'] . "/appcode/images/logo/" . $_FILES["logo-upload"]["name"]);
      }
    else
      {
      move_uploaded_file($_FILES["logo-upload"]["tmp_name"],
      $_SERVER['DOCUMENT_ROOT'] . "/appcode/images/logo/" . $_FILES["logo-upload"]["name"]);
      }
    }
  }
else
  {
  echo "Sorry, Invalid file.";
  }
  
 
  echo "<div style=\"font-size:23px; font-family:helvetica; color:#1569C7;\">";
  echo "<center>Success</center>";
  echo "</div>";
?>