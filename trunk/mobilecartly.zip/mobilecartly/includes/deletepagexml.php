<?
$deletepagexml = $_POST['deletepagexml'];
$deletepagexml = strtolower($deletepagexml);


$pages = simplexml_load_file('../pages.xml');


if(isset($deletepagexml)){
unset($pages->$deletepagexml);
}



#save data
$pages->asXML('../pages.xml');

?>