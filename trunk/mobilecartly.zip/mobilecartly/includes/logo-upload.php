<body bgcolor="#CFECEC">

<div style="margin-left:50px; font-size:23px; font-family:helvetica; color:#1569C7;">
<form action="logo-upload-process.php" method="post" enctype="multipart/form-data">
<label for="file">Filename:</label>
<input type="file" name="logo-upload" id="logo-upload" /> 
<input type="submit" name="submit" value="Submit" style="margin-left:106px; width:85px;"/>
</form>
</div>

</body>