<?
#get pages dynamically
$dir=dir("../pages/");

while($pagenameorig = $dir->read()) {

$pagename = str_replace('-', ' ',  $pagenameorig);
$pagename = str_replace('.php', '',  $pagename);
$pagename = ucfirst($pagename);

if(  strlen($pagename) > 2  ){
echo "<li><a href=\"#mcdialog\" data-rel=\"dialog\" data-rel=\"back\" class=\"pagelink\" id=\"" . strtolower($pagenameorig) . "\">" . $pagename . "</a></li>";
}
}
?>